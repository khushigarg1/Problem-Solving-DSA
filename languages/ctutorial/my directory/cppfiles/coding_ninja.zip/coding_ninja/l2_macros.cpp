#include<iostream>
#include<vector>
#include<string>
#include<cmath>
#include<stack>
#include<algorithm>
using namespace std;
// TO WRITE BETTER CODE WE WILL USE MACROS #define 
#define PI 3.14  // we cannot change this nd ye storage memory bachata hai 

int main(){
    int r;
    cin >> r;
    cout <<" PI * r*r"<< endl;
    // cout <<" 3.14 * r*r"<< endl;   if we dont define pi out of the main fxn the we have a fear ki khi ye pi ki valuechange na ho jaye or define pi se fix ho jati hai none can change this 

return 0;
}
