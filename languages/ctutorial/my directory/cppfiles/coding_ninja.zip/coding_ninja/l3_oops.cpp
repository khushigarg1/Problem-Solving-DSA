/*
ex- lets say i want to create a software development for college university
thennw will need 1-2 studnets professors table classroom, staff member , committee memebr , nd many more things that we can say this will be behave like objects
this will amke our code easy to initialise visualise 
students has some properties like name roll no, age , address, contact naumber nd many mmore
functions like basically a task thaht we can perform tahht all on over obbjects
    like cahngeaddress , setrollnum , nd many more

lets imagine 
 we need 20 students and theri properties are roll no, name , age 
 if we want to create 20 students then we should have three all properteis to every student 
 roll number , name , age
 same xplanantion sb stduenst ko deni pdegi isk aps ye ye nd all

so ek hi information apnko bar bar deni pdhr hi usk lye apn 
ek template bana skte hai jsiak name ho gya students and usk pas hai hr studnets k pas roll num, age , name hoga 
so isk bd sirf hr students k pas iski copy bhej denge taki thoda easy

OOPS -> class is a blueprint thaht defines all properties of our objects dn all
     -> objects 
*/

#include<iostream>
using namespace std;
//SYNTAX OF CLASS
class Student
{
    int rollnumber;
    int age;
}; 

int main(){
    
return 0;
}